# Unikas-CCC
V0.1 Leidžia pasirinkti, ar norėsime studentus skaityti nuo failo ar surašyti patys, leidžiama pasirinkti, kiek studentų bus įvesta, namų darbų skaičius kiekvienam gali būti įvedamas kiek norint kartų. Galiausiai pasirenkama, ar rodoma mediana ar vidurkis ir rezultatai parodomi
